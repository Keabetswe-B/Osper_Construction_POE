#Part 2 Improvements

1. From the feedback I got from my lecture I was supposed to link my github to my project 
2. From the feedback I got from my lecture I was supposed to link my external css file with my html to which I did
3. For the final POE we are meant to style the project using css and make the buttons and everything fuctional using Javascript
4. I added the date time update on all the web pages. 
5. I am going to add SEO in all my web pages
6. created slideshows with javascript

Refernces

1. https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_js_lightbox
2. https://www.w3schools.com/tags/default.asp#gsc.tab=0
3. https://www.w3schools.com/tags/tag_meta.asp