let slideIndex = 1;

showSlides(slideIndex);

function openModal() {
  document.getElementById("myModal").style.display = "block";
}

function closeModal() {
  document.getElementById("myModal").style.display = "none";
}

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  const slides = document.getElementsByClassName("mySlides");
  const dots = document.getElementsByClassName("demo");
  const captionText = document.getElementById("caption");

  if (n > slides.length) { slideIndex = 1; }
  if (n < 1) { slideIndex = slides.length; }

  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }

  for (let i = 0; i < dots.length; i++) {
    dots[i].classList.remove("active");
  }
  if (slides[slideIndex - 1]) {
    slides[slideIndex - 1].style.display = "block";
  }
  if (dots[slideIndex - 1]) {
    dots[slideIndex - 1].classList.add("active");
    if (captionText) {
      captionText.textContent = dots[slideIndex - 1].alt;
    }
  }
}

document.addEventListener("keydown", function(event) {
  const modal = document.getElementById("myModal");
  if (modal && modal.style.display === "block") {
    if (event.key === "Escape") closeModal();
    if (event.key === "ArrowLeft") plusSlides(-1);
    if (event.key === "ArrowRight") plusSlides(1);
  }
});