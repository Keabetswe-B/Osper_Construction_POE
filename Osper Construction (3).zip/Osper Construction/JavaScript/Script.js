// 1. Handle the Main Contact Form
        const contactForm = document.getElementById('contactForm');
        const submitBtn = document.getElementById("submitBtn");
        const formStatus = document.getElementById("formStatus");

        //The admins emails
        const adminEmail = "osperpro@gmail.com";
        
        contactForm.addEventListener("submit", async function(event) {
            // Prevent the page from reloading
            event.preventDefault();

            //Run the browser's built-in validation. 
            if(!contactForm.checkValidity()){
                contactForm.reportValidatity();
                return;
            }

            // Get values from the inputs
            const name = document.getElementById("contactName").value.trim();
            const email = document.getElementById("contactEmail").value.trim();
            const message = document.getElementById("contactMessage").value.trim();

            // Simple validation check for name and message
            if (name == " " || message ===" ") {
                alert("Please fill out all fields before submitting.");
                return;
            }

            // checking if the email is empty and if it is valid
            
            if(email === ""){
                alert("Please fill out all feilds before sumbitting. ")
                return;
            } else if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
                alert("Please eneter a valid email address. ");
                return;
            }

            // Simulate a successful submission
            alert(`Success! ${emailInput} has been subscribed to our newsletter.`);
            
            // Clear the form fields
            contactForm.reset();

            // Prevent repeated clicks while sending.
            submitBtn.disabled = true;
            submitBtn.textContent = "sending...";

            //Sir's thingy
            try{
                //send form data to FormSubmit's Ajax endpoint. 
                const response = await fetch(
                "https://formsubmit.co/ajax/" + encodeURIComponent(adminEmail),
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    },
                    body:vJSON.stringify({
                        name: name,
                        email: document.getElementById(email).value.trim(),
                        message: message,
                        _subject: "New Website Contact Form Submission",
                        _template: "table"
                    })

                }

            );

            const result = await response.json();

            //Only show success if the service confirms acceptance. 
            if(
                response.ok &&
                (
                    result.success === true ||
                    result.sucess === "true"
                )
            ){
                alert("Your Information has been sent successfully!");

                formStatus.textContent = "Thank you! Your message was submitted successfully. ";

                contactForm.reset();
            }else{
                throw new Error(
                    result.message || "The email service did not confirm submission. "
                );
            }

        }catch (error) {
            console.error("Form subission error: ", error);

            formStatus.textContent = "Sorry, your message could not be confirmed. Please try again. ";

            alert(
                "Message not confirmed. Please check your connection " +
                "or try again later. "
            );

        }finally {
            submitBtn.disabled = false;
            submitBtn.textContent = "Send Message";
        }
          

        });
